# DAWA DARBAR — Clean Android Studio Project

## One-click build
1. Install Android Studio (recent stable version).
2. Open this project folder.
3. Allow Gradle sync to finish.
4. Connect an Android device or start an emulator.
5. Click **Run ▶** to install the debug APK.

## Build APK from Android Studio
Use:
**Build → Build Bundle(s) / APK(s) → Build APK(s)**

The generated debug APK will be under:
`app/build/outputs/apk/debug/`

## Command line
On a machine with Gradle/Android SDK configured:
- Windows: `gradlew.bat assembleDebug`
- macOS/Linux: `./gradlew assembleDebug`

## Release APK
Use:
**Build → Generate Signed App Bundle / APK → APK**

Create/select a release keystore and keep the keystore credentials secure.

## Project
Application ID: `com.dawadarbar`
App name: `DAWA DARBAR`
Version: `1.0` (versionCode 1)

This clean project fixes the duplicate MainActivity problem from the previous package.

The UI is intentionally stable and build-focused. Production pharmacy modules (Room persistence, barcode camera, prescriptions, GST/PDF, printer support, WhatsApp Business automation, backups, authentication and audit logs) can be added incrementally without changing the application ID.
