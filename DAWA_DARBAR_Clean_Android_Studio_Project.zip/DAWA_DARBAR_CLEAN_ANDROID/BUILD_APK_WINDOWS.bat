@echo off
setlocal
echo ============================================
echo DAWA DARBAR - DEBUG APK BUILD
echo ============================================
if not exist "%~dp0gradlew.bat" (
  echo Gradle wrapper is not included because this package is designed
  echo to be opened in Android Studio, which supplies the Gradle tooling.
  echo.
  echo Open this project in Android Studio and use:
  echo Build ^> Build Bundle(s) / APK(s) ^> Build APK(s)
  pause
  exit /b 1
)
call "%~dp0gradlew.bat" assembleDebug
if %ERRORLEVEL% EQU 0 (
  echo.
  echo APK created at:
  echo appuild\outputspk\debugpp-debug.apk
) else (
  echo Build failed. Check the Gradle/Android SDK configuration.
)
pause
