package com.dawadarbar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Medicine(
    val name: String,
    val batch: String,
    val expiry: String,
    val stock: Int,
    val mrp: Double
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DawaDarbarApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DawaDarbarApp() {
    var screen by remember { mutableStateOf("Dashboard") }
    val medicines = remember {
        listOf(
            Medicine("Paracetamol 500 mg", "PCM001", "05/2027", 120, 18.0),
            Medicine("Azithromycin 500 mg", "AZI009", "08/2027", 18, 65.0),
            Medicine("ORS Powder", "ORS101", "12/2026", 8, 22.0),
            Medicine("Amoxicillin 500 mg", "AMX200", "03/2027", 0, 48.0)
        )
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("DAWA DARBAR", fontWeight = FontWeight.Bold)
                            Text("Retail Pharmacy", fontSize = 12.sp)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    val tabs = listOf(
                        "Dashboard" to Icons.Default.Home,
                        "Billing" to Icons.Default.ShoppingCart,
                        "Stock" to Icons.Default.Inventory,
                        "Orders" to Icons.Default.List,
                        "Customers" to Icons.Default.People
                    )
                    tabs.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = screen == label,
                            onClick = { screen = label },
                            icon = { Icon(icon, label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            when (screen) {
                "Dashboard" -> Dashboard(padding, medicines) { screen = it }
                "Billing" -> Billing(padding, medicines)
                "Stock" -> Stock(padding, medicines)
                "Orders" -> Placeholder(padding, "Orders", "Prescription and order workflow")
                "Customers" -> Placeholder(padding, "Customers", "Customer profiles and purchase history")
            }
        }
    }
}

@Composable
private fun Dashboard(
    padding: PaddingValues,
    medicines: List<Medicine>,
    navigate: (String) -> Unit
) {
    val low = medicines.count { it.stock < 20 }
    val out = medicines.count { it.stock == 0 }

    Column(Modifier.padding(padding).padding(16.dp)) {
        Text("Dashboard", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Today's Sales", "₹18,450", Modifier.weight(1f))
            MetricCard("Profit", "₹3,240", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Low Stock", low.toString(), Modifier.weight(1f))
            MetricCard("Out of Stock", out.toString(), Modifier.weight(1f))
        }

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { navigate("Billing") },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) {
            Icon(Icons.Default.AddShoppingCart, null)
            Spacer(Modifier.width(8.dp))
            Text("NEW BILL", fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = { navigate("Stock") },
            modifier = Modifier.fillMaxWidth()
        ) { Text("INVENTORY & EXPIRY") }

        Spacer(Modifier.height(18.dp))
        Text("Quick Alerts", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        AlertRow("Low stock medicines", "$low items")
        AlertRow("Out of stock", "$out items")
        AlertRow("Expiry review", "Check batches expiring within 90 days")
    }
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontSize = 12.sp)
            Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AlertRow(title: String, detail: String) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(detail) },
        leadingContent = { Icon(Icons.Default.Warning, null) }
    )
}

@Composable
private fun Billing(padding: PaddingValues, medicines: List<Medicine>) {
    var query by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(listOf<Medicine>()) }

    Column(Modifier.padding(padding).padding(16.dp)) {
        Text("New Bill", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Medicine / barcode") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            singleLine = true
        )

        medicines
            .filter { query.isNotBlank() && it.name.contains(query, true) }
            .forEach { medicine ->
                ListItem(
                    headlineContent = { Text(medicine.name) },
                    supportingContent = {
                        Text("Batch ${medicine.batch} • Stock ${medicine.stock} • MRP ₹${medicine.mrp}")
                    },
                    trailingContent = {
                        Button(
                            enabled = medicine.stock > 0,
                            onClick = { cart = cart + medicine }
                        ) { Text("ADD") }
                    }
                )
            }

        HorizontalDivider()
        Spacer(Modifier.height(8.dp))
        Text("Cart (${cart.size})", fontWeight = FontWeight.Bold)

        cart.forEach { medicine ->
            ListItem(
                headlineContent = { Text(medicine.name) },
                trailingContent = { Text("₹${medicine.mrp}") }
            )
        }

        Spacer(Modifier.weight(1f))
        val total = cart.sumOf { it.mrp }
        Button(
            onClick = { },
            enabled = cart.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) {
            Text("PAY ₹${"%.2f".format(total)}", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Stock(padding: PaddingValues, medicines: List<Medicine>) {
    var query by remember { mutableStateOf("") }

    Column(Modifier.padding(padding).padding(16.dp)) {
        Text("Inventory", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Search medicine / batch") },
            leadingIcon = { Icon(Icons.Default.Search, null) }
        )

        LazyColumn {
            items(medicines.filter {
                it.name.contains(query, true) || it.batch.contains(query, true)
            }) { medicine ->
                ListItem(
                    headlineContent = {
                        Text(medicine.name, fontWeight = FontWeight.SemiBold)
                    },
                    supportingContent = {
                        Text("Batch ${medicine.batch} • Expiry ${medicine.expiry}")
                    },
                    trailingContent = {
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Qty ${medicine.stock}", fontWeight = FontWeight.Bold)
                            Text("MRP ₹${medicine.mrp}")
                        }
                    }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun Placeholder(padding: PaddingValues, title: String, description: String) {
    Box(
        Modifier.padding(padding).fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Construction, null, Modifier.size(48.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(description)
        }
    }
}
